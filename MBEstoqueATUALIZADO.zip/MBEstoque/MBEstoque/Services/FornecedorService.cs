using MBCEstoque.Data;
using MBCEstoque.Models;
using MBCEstoque.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace MBCEstoque.Services
{
    public class FornecedorService : IFornecedorService
    {
        // SOLID -D --INJEÇÃO DE DEPENDÊNCIA
        private readonly SQLServerEstoqueDbContext _context;

        public FornecedorService(SQLServerEstoqueDbContext context)
        {
            _context = context;
        }

        // CRUD -- Read
        public async Task<List<Fornecedor>> ListarTodosFornecedor()
        {
            return await _context.Fornecedores.AsNoTracking().ToListAsync();
        }
        //CRUD - CREAT - UPDATE - DELETE
        public async Task<Fornecedor?> PesquisarFornecedorPorId(int id)
        {
            var fornecedor=await _context.Fornecedores.AsNoTracking().FirstOrDefaultAsync(f=>f.Id==id);
            return fornecedor;
        }
        public async Task<Fornecedor> CriarAsync(Fornecedor fornecedor)
        {
            _context.Fornecedores.Add(fornecedor);
            await _context.SaveChangesAsync();
            return fornecedor;
        }
        public async Task<bool> AlterarAsync(Fornecedor fornecedor)
        {
            var existe = await _context.Fornecedores.AnyAsync(f=>f.Id==fornecedor.Id);
            if(!existe)
            {
                return false;
            }
            _context.Fornecedores.Update(fornecedor);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> ExcluirAsync(int id)
        {
            var fornecedor = await _context.Fornecedores.FindAsync(id);
            if (fornecedor is null)
            {
                return false;
            }
            _context.Fornecedores.Remove(fornecedor);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
