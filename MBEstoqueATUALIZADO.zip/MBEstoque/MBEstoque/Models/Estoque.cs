﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MBCEstoque.Models
{
    public class Estoque
    {
        [Key]
        public int Id { get; set; }
        public int ProdutoId { get; set; }
        [ForeignKey(nameof(ProdutoId))]
        public virtual Produto Produto { get; set; }
        [Range(0, int.MaxValue,ErrorMessage ="Quantidade não pode ser negativa")]
        public int QuantidadeAtual { get; set; }
        public int EstoqueMinimo { get; set; }
        public int EstoqueMaximo { get;set; }
        [MaxLength(100)]
        public string? Localizacao { get; set; }
        public DateTime UtimaAtualizacao { get; set; } = DateTime.Now;
        public bool EstaBaixo => QuantidadeAtual < EstoqueMinimo;
        public string Status =>
            QuantidadeAtual == 0 ? "Sem estoque" :
            QuantidadeAtual < EstoqueMinimo ? "Critico" :
            QuantidadeAtual >= EstoqueMaximo ? "Cheio" : "Normal";
    }
}
