using MBCEstoque.Data;
using MBCEstoque.Models;
using MBCEstoque.Models.Enums;
using MBCEstoque.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace MBCEstoque.Services
{
    public class EstoqueService : IEstoqueService
    {
        // SOLID-D: Injeção de Dependência via construtor
        private readonly SQLServerEstoqueDbContext _context;

        public EstoqueService(SQLServerEstoqueDbContext context)
        {
            _context = context;
        }

        // ── ENTRADA DE ESTOQUE ────────────────────────────────────────────
        // Registra uma entrada de mercadoria e atualiza o saldo do estoque.
        public async Task<MovimentacaoEstoque> RegistrarEntradaAsync(
            int produtoId, int quantidade, string? obs = null)
        {
            if (quantidade <= 0)
                throw new ArgumentException("A quantidade de entrada deve ser maior que zero.", nameof(quantidade));

            // Busca o registro de estoque vinculado ao produto (rastreado para permitir update)
            var estoque = await _context.Estoques
                .FirstOrDefaultAsync(e => e.ProdutoId == produtoId);

            if (estoque is null)
                throw new InvalidOperationException($"Nenhum registro de estoque encontrado para o produto ID {produtoId}.");

            // Captura snapshot antes da operação (para auditoria)
            var quantidadeAnterior = estoque.QuantidadeAtual;

            // Atualiza o saldo
            estoque.QuantidadeAtual += quantidade;
            estoque.UtimaAtualizacao = DateTime.UtcNow;

            // Cria o registro de movimentação para auditoria
            var movimentacao = new MovimentacaoEstoque
            {
                ProdutoId      = produtoId,
                TipoMovimentacao = TipoMovimentacao.Entrada,
                Quantidade       = quantidade,
                QuantidadeAnterior = quantidadeAnterior,
                QuantidadeAtual    = estoque.QuantidadeAtual,
                Observacao       = obs,
                DataMovimentacao = DateTime.UtcNow
            };

            _context.Movimentacoes.Add(movimentacao);
            await _context.SaveChangesAsync();

            return movimentacao;
        }

        // ── SAÍDA DE ESTOQUE ──────────────────────────────────────────────
        // Registra uma saída de mercadoria validando que não ficará negativo.
        public async Task<MovimentacaoEstoque> RegistrarSaidaAsync(
            int produtoId, int quantidade, string? obs = null)
        {
            if (quantidade <= 0)
                throw new ArgumentException("A quantidade de saída deve ser maior que zero.", nameof(quantidade));

            var estoque = await _context.Estoques
                .FirstOrDefaultAsync(e => e.ProdutoId == produtoId);

            if (estoque is null)
                throw new InvalidOperationException($"Nenhum registro de estoque encontrado para o produto ID {produtoId}.");

            // Regra de negócio: impede que o estoque fique negativo
            if (estoque.QuantidadeAtual < quantidade)
                throw new InvalidOperationException(
                    $"Saldo insuficiente. Disponível: {estoque.QuantidadeAtual}, solicitado: {quantidade}.");

            var quantidadeAnterior = estoque.QuantidadeAtual;

            // Deduz do saldo
            estoque.QuantidadeAtual -= quantidade;
            estoque.UtimaAtualizacao = DateTime.UtcNow;

            var movimentacao = new MovimentacaoEstoque
            {
                ProdutoId        = produtoId,
                TipoMovimentacao = TipoMovimentacao.Saida,
                Quantidade         = quantidade,
                QuantidadeAnterior = quantidadeAnterior,
                QuantidadeAtual    = estoque.QuantidadeAtual,
                Observacao         = obs,
                DataMovimentacao   = DateTime.UtcNow
            };

            _context.Movimentacoes.Add(movimentacao);
            await _context.SaveChangesAsync();

            return movimentacao;
        }
    }
}
