package com.example.contatos.persistencia;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.contatos.model.Contato;

import java.util.ArrayList;
import java.util.List;

public class ContatoDAO implements IContatoDAO {
    private SQLiteDatabase escreve;
    private SQLiteDatabase le;

    public ContatoDAO(Context context) {
        DbHelper db = new DbHelper(context);
        escreve = db.getWritableDatabase();
        le = db.getReadableDatabase();
    }

    @Override
    public boolean salvar(Contato contato) {
        ContentValues cv = new ContentValues();
        cv.put("nomeContato", contato.getNomeContato());
        cv.put("telContato", contato.getTelContato());
        try {
            escreve.insert(DbHelper.TABELA_CONTATO, null, cv);
            Log.i("InfoDB", "Sucesso ao salvar o registro");
        } catch (Exception e) {
            Log.e("InfoDB", "Erro ao salvar o registro. Erro: " + e.getMessage());
            return false;
        }
        return true;
    }

    @Override
    public boolean atualizar(Contato contato) {
        ContentValues cv = new ContentValues();
        cv.put("nomeContato", contato.getNomeContato());
        cv.put("telContato", contato.getTelContato());
        try {
            String[] args = {contato.getId().toString()};
            escreve.update(DbHelper.TABELA_CONTATO, cv, "id=?", args);
            Log.i("InfoDB", "Sucesso ao alterar o registro");
        } catch (Exception e) {
            Log.e("InfoDB", "Erro ao alterar o registro. Erro: " + e.getMessage());
            return false;
        }
        return true;
    }

    @Override
    public boolean excluir(Contato contato) {
        try {
            String[] args = {contato.getId().toString()};
            escreve.delete(DbHelper.TABELA_CONTATO, "id=?", args);
            Log.i("InfoDB", "Sucesso ao excluir o registro");
        } catch (Exception e) {
            Log.e("InfoDB", "Erro ao excluir o registro. Erro: " + e.getMessage());
            return false;
        }
        return true;
    }

    @Override
    public List<Contato> Listar() {
        List<Contato> lstContato = new ArrayList<>();
        String sql = "SELECT * FROM " + DbHelper.TABELA_CONTATO + " ;";

        try (Cursor cursor = le.rawQuery(sql, null)) {
            int indexId = cursor.getColumnIndexOrThrow("id");
            int indexNome = cursor.getColumnIndexOrThrow("nomeContato");
            int indexTel = cursor.getColumnIndexOrThrow("telContato");

            while (cursor.moveToNext()) {
                Contato contato = new Contato();
                contato.setId(cursor.getLong(indexId));
                contato.setNomeContato(cursor.getString(indexNome));
                contato.setTelContato(cursor.getString(indexTel));
                lstContato.add(contato);
            }
            Log.i("InfoDB", "Sucesso ao pesquisar os registros");
            return lstContato;
        } catch (Exception e) {
            Log.e("InfoDB", "Erro ao pesquisar os registros", e);
        }

        return lstContato;
    }
}
