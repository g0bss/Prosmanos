using MBCEstoque.Data;
using MBCEstoque.Models;
using MBCEstoque.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace MBCEstoque.Services
{
    public class ProdutoService : IProdutoService
    {
        // SOLID-D: Injeção de Dependência via construtor
        private readonly SQLServerEstoqueDbContext _context;

        public ProdutoService(SQLServerEstoqueDbContext context)
        {
            _context = context;
        }

        // ── READ ──────────────────────────────────────────────────────────
        public async Task<List<Produto>> ListarTodosProdutos()
        {
            return await _context.Produtos
                .AsNoTracking()
                .Include(p => p.Categoria)
                .Include(p => p.Fornecedor)
                .Include(p => p.Estoque)
                .ToListAsync();
        }

        public async Task<Produto?> PesquisarProdutoPorId(int id)
        {
            return await _context.Produtos
                .AsNoTracking()
                .Include(p => p.Categoria)
                .Include(p => p.Fornecedor)
                .Include(p => p.Estoque)
                .FirstOrDefaultAsync(p => p.Id == id);
        }

        // ── CREATE ────────────────────────────────────────────────────────
        public async Task<Produto> CriarAsync(Produto produto)
        {
            // Garante que a data de cadastro seja atribuída no servidor
            produto.DataCadastro = DateTime.UtcNow;
            produto.Ativo = true;

            _context.Produtos.Add(produto);
            await _context.SaveChangesAsync();
            return produto;
        }

        // ── UPDATE ────────────────────────────────────────────────────────
        public async Task<bool> AlterarAsync(Produto produto)
        {
            var existe = await _context.Produtos.AnyAsync(p => p.Id == produto.Id);
            if (!existe)
            {
                return false;
            }

            _context.Produtos.Update(produto);
            await _context.SaveChangesAsync();
            return true;
        }

        // ── DELETE ────────────────────────────────────────────────────────
        public async Task<bool> ExcluirAsync(int id)
        {
            var produto = await _context.Produtos.FindAsync(id);
            if (produto is null)
            {
                return false;
            }

            // Soft delete: mantém o histórico de movimentações intacto
            produto.Ativo = false;
            _context.Produtos.Update(produto);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
