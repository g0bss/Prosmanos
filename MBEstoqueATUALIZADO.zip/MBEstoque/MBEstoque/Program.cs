using MBCEstoque.Components;
using MBCEstoque.Data;
using MBCEstoque.Services;
using MBCEstoque.Services.Interfaces;
using Microsoft.EntityFrameworkCore;
using MudBlazor.Services;

var builder = WebApplication.CreateBuilder(args);

// ── 1. DbContext ──────────────────────────────────────────────────────────────
builder.Services.AddDbContext<SQLServerEstoqueDbContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("DefaultConnection"),
        sqlOptions => sqlOptions.EnableRetryOnFailure(
            maxRetryCount: 5,
            maxRetryDelay: TimeSpan.FromSeconds(30),
            errorNumbersToAdd: null
        )
    ));
// ── 2. Services (Injeção de Dependência) ─────────────────────────────────────
builder.Services.AddScoped<ICategoriaService, CategoriaService>();
builder.Services.AddScoped<IEstoqueService, EstoqueService>();
builder.Services.AddScoped<IFornecedorService, FornecedorService>();
builder.Services.AddScoped<IProdutoService, ProdutoService>();



// Add MudBlazor services
builder.Services.AddMudServices();

// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

var app = builder.Build();

// ── Auto-migração ─────────────────────────────────────────────────────────────
// Aplica todas as migrations pendentes automaticamente ao iniciar.
// O banco de dados deve existir previamente (o EF Core não tem permissão de
// executar CREATE DATABASE neste ambiente).
using (var scope = app.Services.CreateScope())
{
    var db    = scope.ServiceProvider.GetRequiredService<SQLServerEstoqueDbContext>();
    var logger = scope.ServiceProvider.GetRequiredService<ILogger<Program>>();

    try
    {
        // Verifica conectividade antes de tentar migrar
        if (!await db.Database.CanConnectAsync())
        {
            logger.LogError(
                "Não foi possível conectar ao banco de dados. " +
                "Verifique a connection string em appsettings.json e certifique-se " +
                "de que o banco '{Database}' existe no servidor.",
                db.Database.GetDbConnection().Database);
        }
        else
        {
            await db.Database.MigrateAsync();
            logger.LogInformation("Migrations aplicadas com sucesso.");
        }
    }
    catch (Microsoft.Data.SqlClient.SqlException ex) when (ex.Number == 262)
    {
        // Erro 262 = CREATE DATABASE permission denied
        // O banco já existe mas o usuário não tem permissão de criá-lo;
        // isso pode ocorrer na primeira execução quando o EF tenta recriar.
        logger.LogWarning(
            "Permissão de CREATE DATABASE negada. Tentando aplicar apenas as migrations...");
        try
        {
            // Tenta somente as migrations pendentes (sem criar o banco)
            var pendingMigrations = await db.Database.GetPendingMigrationsAsync();
            if (pendingMigrations.Any())
            {
                await db.Database.MigrateAsync();
                logger.LogInformation("Migrations aplicadas com sucesso.");
            }
        }
        catch (Exception innerEx)
        {
            logger.LogError(innerEx,
                "Falha ao aplicar migrations. Certifique-se de que o banco " +
                "'{Database}' existe e que o usuário tem permissão de acesso.",
                db.Database.GetDbConnection().Database);
        }
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "Erro inesperado durante a migração do banco de dados.");
    }
}


// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}
app.UseStatusCodePagesWithReExecute("/not-found", createScopeForStatusCodePages: true);

app.UseHttpsRedirection();


app.UseAntiforgery();

app.MapStaticAssets();
app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
