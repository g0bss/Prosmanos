package com.example.contatos;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.contatos.adapter.AdapterContato;
import com.example.contatos.model.Contato;
import com.example.contatos.persistencia.ContatoDAO;

import java.util.ArrayList;
import java.util.List;

public class ListaContatoActivity extends AppCompatActivity {
    Button btnNovo;
    RecyclerView recyclerContato;
    private AdapterContato contatoAdapter;
    private Contato contatoSelecionado;
    private List<Contato> listaContatos = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_lista_contato);

        recyclerContato = (RecyclerView) findViewById(R.id.rvListaContato);
        btnNovo = (Button) findViewById(R.id.cmdNovo);
        btnNovo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intencao = new Intent(ListaContatoActivity.this, AddContatoActivity.class);
                startActivity(intencao);
            }
        });
        recyclerContato.addOnItemTouchListener(new RecyclerItemClickListener(getApplicationContext(), recyclerContato, new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                contatoSelecionado = listaContatos.get(position);
                Intent intencao = new Intent(ListaContatoActivity.this, AddContatoActivity.class);
                intencao.putExtra("contatoSelecionado", contatoSelecionado);
                startActivity(intencao);

            }

            @Override
            public void onLongItemClick(View view, int position) {
                //Recuperar o contato que será excluído
                contatoSelecionado = listaContatos.get(position);
                AlertDialog.Builder dialog = new AlertDialog.Builder(ListaContatoActivity.this);
                //configurar o AlertDialog.Builder
                dialog.setTitle("Confirmar a exclusão");
                dialog.setMessage("Deseja excluir o contato:" + contatoSelecionado.getNomeContato() + "?");
                dialog.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        ContatoDAO contatoDAO = new ContatoDAO(getApplicationContext());
                        if (contatoDAO.excluir(contatoSelecionado)) {
                            carregarListaContatos();
                            Toast.makeText(ListaContatoActivity.this, "Sucesso ao excluir o registro", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(ListaContatoActivity.this, "Erro ao excluir o registro", Toast.LENGTH_SHORT).show();
                        }

                    }
                });
                dialog.setNegativeButton("Não", null);
                dialog.create();
                dialog.show();
            }

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            }
        }));
    }

    public void carregarListaContatos() {
        ContatoDAO contatoDAO = new ContatoDAO(getApplicationContext());
        listaContatos = contatoDAO.Listar();
        //Configurar o meu adapter
        contatoAdapter = new AdapterContato(listaContatos);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerContato.setLayoutManager(layoutManager);
        recyclerContato.setHasFixedSize(true);
        recyclerContato.addItemDecoration(new DividerItemDecoration(getApplicationContext(), LinearLayout.VERTICAL));
        recyclerContato.setAdapter(contatoAdapter);
    }

    @Override
    protected void onStart() {
        carregarListaContatos();
        super.onStart();
    }
}
