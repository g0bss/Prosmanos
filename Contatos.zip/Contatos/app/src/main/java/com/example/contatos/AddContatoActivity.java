package com.example.contatos;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.contatos.model.Contato;
import com.example.contatos.persistencia.ContatoDAO;

public class AddContatoActivity extends AppCompatActivity {
    TextView tvAcao;
    EditText edtNome, edtTelefone;
    Button btnSalvar;
    private Contato contatoAtual;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_contato);

        tvAcao = (TextView) findViewById(R.id.lblAcao);
        edtNome = (EditText) findViewById(R.id.txtNome);
        edtTelefone = (EditText) findViewById(R.id.txtTelefone);
        btnSalvar = (Button) findViewById(R.id.cmdSalvar);
        contatoAtual = (Contato) getIntent().getSerializableExtra("contatoSelecionado");
        if(contatoAtual!=null){
            edtNome.setText(contatoAtual.getNomeContato());
            edtTelefone.setText(contatoAtual.getTelContato());

        }
        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ContatoDAO contatoDAO = new ContatoDAO(getApplicationContext());
                String nomeContato = edtNome.getText().toString();
                String telContato = edtTelefone.getText().toString();
                if(contatoAtual!=null){
                    tvAcao.setText("Editar Contato Existente");
                    if(!nomeContato.isEmpty()){
                        Contato contato = new Contato();
                        contato.setNomeContato(nomeContato);
                        contato.setTelContato(telContato);
                        contato.setId(contatoAtual.getId());
                        if(contatoDAO.atualizar(contato)){
                            finish();
                            Toast.makeText(getApplicationContext(),"Sucesso ao atualizar o registro", Toast.LENGTH_SHORT).show();
                        }else{
                            Toast.makeText(getApplicationContext(),"Erro ao atualizar o registro", Toast.LENGTH_SHORT).show();
                        }
                    }

                }else{
                    tvAcao.setText("Incluir Novo Contato");
                    if(!nomeContato.isEmpty()){
                        Contato contato = new Contato();
                        contato.setNomeContato(nomeContato);
                        contato.setTelContato(telContato);
                        if(contatoDAO.salvar(contato)){
                            finish();
                            Toast.makeText(getApplicationContext(),"Sucesso ao salvar o registro", Toast.LENGTH_SHORT).show();
                        }else{
                            Toast.makeText(getApplicationContext(),"Erro ao salvar o registro", Toast.LENGTH_SHORT).show();
                        }
                    }

                }
            }
        });
    }
}
