package com.example.contatos.persistencia;

import com.example.contatos.model.Contato;

import java.util.List;

public interface IContatoDAO {
    public boolean salvar(Contato contato);
    public boolean atualizar(Contato contato);
    public boolean excluir(Contato contato);
    public List<Contato> Listar ();
}

